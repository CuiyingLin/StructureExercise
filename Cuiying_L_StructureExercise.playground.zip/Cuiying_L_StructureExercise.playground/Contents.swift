import UIKit

struct Engine {
    var type1 = "v4"
    var type2 = "v6"
    var type3 = "v8"
}

let selection = Engine()

print("I will select the car with a \(selection.type1) engine.")
